# Geometry Dash — Cadence frontend deployment

Public website: `https://geometrydash.devs.li`

## Build

Use GitHub Actions → **Build Cadence web frontend**. It installs Rust stable, `wasm32-unknown-unknown`, and the `wasm-bindgen-cli` version pinned to the lockfile, then builds the real Cadence WASM. Download the `cadence-geometrydash-frontend` artifact. Alternatively run `tools/build-web.sh` locally with Rust 1.90+ and Cargo installed.

The static artifact contains `index.html`, `site.js`, and `pkg/cadence_game.js` + `pkg/cadence_game_bg.wasm`. The project source ZIP itself is not a compiled website.

## Deploy

1. Publish the artifact contents to the Enzonic frontend project/custom domain `geometrydash.devs.li`.
2. Deploy `relay/worker.js` with `wrangler.toml` as the site's Worker.
3. Configure the Worker variable `API_ORIGIN` to the backend's Enzonic service origin (the backend service host, not this public frontend hostname).
4. The Worker proxies `/api/*`, `/relay/database/*`, `/relay/post`, and `/database/*` to that backend. Other paths are static assets.
5. Keep observability disabled.

The backend must have `PUBLIC_SITE_URL=https://geometrydash.devs.li` and `CORS_ORIGIN=https://geometrydash.devs.li`. Preserve all four existing database URLs.

## Resources

Cadence does not include copyrighted Geometry Dash assets. A player must select their own Geometry Dash 2.2091 Resources folder in the browser. The browser reads it locally; it is not uploaded. Without those files, the actual game cannot render.

## Online ownership

The worker no longer forwards POST requests to Boomlings. Cadence's own request bodies are handled by the Enzonic protocol adapter. The `/relay/get` path only allows approved custom-song/content file hosts; that is separate from accounts, levels, saves, and social data.

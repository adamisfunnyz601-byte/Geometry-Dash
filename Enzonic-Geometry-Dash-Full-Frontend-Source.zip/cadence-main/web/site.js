(() => {
  const $ = id => document.getElementById(id);
  const api = async (path, options={}) => {
    const headers = new Headers(options.headers || {});
    if (options.body && !headers.has('Content-Type')) headers.set('Content-Type','application/json');
    const token = localStorage.getItem('gd-session-token');
    if (token) headers.set('Authorization',`Bearer ${token}`);
    const r = await fetch(`/api${path}`, {...options, headers});
    const body = await r.json().catch(()=>({error:`HTTP ${r.status}`}));
    if (!r.ok) throw new Error(body.error || `HTTP ${r.status}`);
    return body;
  };
  const status = (id, message, error=false) => { const el=$(id); if (!el) return; el.textContent=message; el.classList.toggle('error',error); };
  const row = (title, detail, action) => {
    const el=document.createElement('div'); el.className='site-row';
    if (action) { el.setAttribute('role','button'); el.tabIndex=0; el.addEventListener('click',action); el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();action();}}); }
    const strong=document.createElement('strong'); strong.textContent=title;
    const small=document.createElement('small'); small.textContent=detail;
    el.append(strong,small); return el;
  };
  async function loadLevels(search='') {
    const target=$('site-level-results'); if (!target) return;
    target.replaceChildren(Object.assign(document.createElement('div'),{className:'site-status',textContent:'Loading…'}));
    try {
      const data=await api(`/levels?search=${encodeURIComponent(search)}&limit=20`);
      target.replaceChildren();
      if (!data.levels?.length) { statusNode(target,'No levels found yet. Publish one from Cadence’s editor.'); return; }
      for (const level of data.levels) target.append(row(level.name,`${level.creator} · ${level.average_rating||'0.00'}★`,()=>loadLevelDetail(level.id)));
    } catch(e) { statusNode(target,e.message,true); }
  }
  function statusNode(target,message,error=false) { const n=document.createElement('div'); n.className='site-status'+(error?' error':''); n.textContent=message; target.replaceChildren(n); }
  async function loadLeaderboard() {
    const target=$('site-leaderboard'); if (!target) return;
    try {
      const data=await api('/leaderboards?metric=stars&limit=10'); target.replaceChildren();
      if (!data.entries?.length) return statusNode(target,'No ranked players yet.');
      for (const entry of data.entries) target.append(row(`#${entry.rank} ${entry.username}`,`${entry.stars} stars`,()=>loadProfile(entry.username)));
    } catch(e) { statusNode(target,e.message,true); }
  }
  function showDetail(title, lines) {
    const box=$('site-detail'); if (!box) return;
    box.hidden=false; box.replaceChildren();
    const h=document.createElement('h3'); h.textContent=title; box.append(h);
    for (const line of lines) { const p=document.createElement('p'); p.textContent=line; box.append(p); }
    const close=document.createElement('button'); close.className='quiet'; close.type='button'; close.textContent='Close'; close.addEventListener('click',()=>box.hidden=true); box.append(close);
  }
  async function loadLevelDetail(id) {
    try { const data=await api(`/levels/${id}`); const l=data.level; showDetail(l.name,[`Creator: ${l.creator||'Unknown'}`,`Level ID: ${l.id}`,`Description: ${l.description||'No description'}`,`Rating: ${l.average_rating||'0.00'} (${l.rating_count||0} votes)`,`Published: ${new Date(l.created_at).toLocaleDateString()}`,'To play it, open the in-game Online Levels browser in Cadence.']); }
    catch(e) { showDetail('Unable to load level',[e.message]); }
  }
  async function loadProfile(username) {
    try { const data=await api(`/profiles/${encodeURIComponent(username)}`); const s=data.stats||{}; showDetail(data.user.username,[data.profile?.bio||'No player bio',`Stars: ${s.stars||0} · Demons: ${s.demons||0} · Diamonds: ${s.diamonds||0}`,`Creator points: ${s.creator_points||0} · Published levels: ${data.levelCount||0}`]); }
    catch(e) { showDetail('Unable to load profile',[e.message]); }
  }
  $('site-level-search-btn')?.addEventListener('click',()=>loadLevels($('site-level-search').value));
  $('site-level-recent-btn')?.addEventListener('click',()=>{ $('site-level-search').value=''; loadLevels(''); });
  $('site-level-search')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();loadLevels(e.currentTarget.value);}});
  $('site-register')?.addEventListener('submit',async e=>{
    e.preventDefault(); const f=new FormData(e.currentTarget);
    try { const data=await api('/auth/register',{method:'POST',body:JSON.stringify({username:f.get('username'),password:f.get('password'),email:f.get('email')||undefined})});
      localStorage.setItem('gd-session-token',data.token); status('site-register-status',`Account created: ${data.user.username}. You can now log in inside Cadence.`); status('site-login-status','Signed in on this website.');
    } catch(err) { status('site-register-status',err.message,true); }
  });
  $('site-login')?.addEventListener('submit',async e=>{
    e.preventDefault(); const f=new FormData(e.currentTarget);
    try { const data=await api('/auth/login',{method:'POST',body:JSON.stringify({username:f.get('username'),password:f.get('password')})});
      localStorage.setItem('gd-session-token',data.token); status('site-login-status',`Signed in as ${data.user.username}. Cadence account login is ready.`);
    } catch(err) { status('site-login-status',err.message,true); }
  });
  $('site-logout')?.addEventListener('click',()=>{localStorage.removeItem('gd-session-token');status('site-login-status','Signed out.');});
  loadLevels(); loadLeaderboard();
})();

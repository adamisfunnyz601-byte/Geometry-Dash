#!/bin/bash
# Build the web version into web/pkg (wasm + JS glue). Serve web/ with any static server.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/opt/homebrew/opt/rustup/bin:$HOME/.cargo/bin:$PATH"
cd "$root"
rustup target add wasm32-unknown-unknown
cargo build --locked --release -p cadence-game --lib --target wasm32-unknown-unknown
if ! command -v wasm-bindgen >/dev/null 2>&1; then
    cargo install wasm-bindgen-cli --version 0.2.130 --locked
fi
wasm-bindgen --target web --no-typescript --out-dir web/pkg \
    target/wasm32-unknown-unknown/release/cadence_game.wasm
ls -la web/pkg/*.wasm

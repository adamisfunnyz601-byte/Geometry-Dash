// Cadence website worker. All account/game/community requests are served by our own Enzonic
// Node backend. Boomlings is deliberately not an upstream for any POST request.
// Configure API_ORIGIN as the backend's Enzonic service URL (not the public frontend URL).
const GET_HOSTS = [/^geometrydashfiles\.b-cdn\.net$/, /^geometrydashcontent\.b-cdn\.net$/, /(^|\.)ngfiles\.com$/, /^(www\.)?newgrounds\.com$/];
const MAX_BODY = 18 << 20;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/relay/database/') || url.pathname.startsWith('/database/') || url.pathname === '/relay/post') {
      if (!env || !env.API_ORIGIN) return text(503, 'backend API_ORIGIN is not configured');
      const origin = String(env.API_ORIGIN).replace(/\/$/, '');
      const target = origin + url.pathname + url.search;
      return forward(target, request);
    }
    if (url.pathname === '/relay/get' && request.method === 'GET') return getContent(url);
    return env && env.ASSETS ? env.ASSETS.fetch(request) : text(404, 'not found');
  },
};

async function forward(target, request) {
  const body = await request.arrayBuffer();
  if (body.byteLength > MAX_BODY) return text(413, 'request too large');
  const headers = new Headers();
  for (const name of ['content-type', 'accept', 'authorization']) {
    const value = request.headers.get(name);
    if (value) headers.set(name, value);
  }
  const resp = await fetch(target, { method: request.method, headers, body: request.method === 'GET' || request.method === 'HEAD' ? undefined : body, redirect: 'manual' });
  return new Response(resp.body, { status: resp.status, headers: {
    'Content-Type': resp.headers.get('Content-Type') || 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': request.headers.get('Origin') || '*',
  }});
}

async function getContent(url) {
  let target;
  try { target = new URL(url.searchParams.get('u') || ''); } catch { return text(400, 'not an approved content URL'); }
  if (!['https:', 'http:'].includes(target.protocol) || target.username || target.password || !GET_HOSTS.some(h => h.test(target.hostname))) return text(400, 'not an approved content URL');
  const resp = await fetch(target.href, { headers: { 'User-Agent': '' }, cf: { cacheTtl: 86400, cacheEverything: true } });
  return new Response(resp.body, { status: resp.status, headers: {
    'Content-Type': resp.headers.get('Content-Type') || 'application/octet-stream',
    'Cache-Control': 'public, max-age=86400'
  }});
}
function text(status, message) { return new Response(message, { status, headers: { 'Content-Type': 'text/plain; charset=utf-8' } }); }

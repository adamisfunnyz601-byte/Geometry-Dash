# Enzonic Geometry Dash — Full Frontend Source

This archive preserves the complete Cadence project and also places `index.html` and `site.js` at the ZIP root so a static host can discover the homepage.

## Important: source vs compiled website
This is the full project source, not the compiled playable WASM artifact. The original project did not contain `web/pkg/cadence_game.js` or `web/pkg/cadence_game_bg.wasm`. Build those with the included GitHub Actions workflow at `cadence-main/.github/workflows/web.yml` (or `cadence-main/tools/build-web.sh` with Rust and wasm-bindgen installed). Deploy the contents of the resulting `target/site` artifact for the fully playable game.

## Website
Public site: https://geometrydash.devs.li

The root homepage uses `site.js` and expects the Enzonic backend to be routed under `/api`. The complete source, relay worker, workflow, and deployment notes are retained under `cadence-main/`.
